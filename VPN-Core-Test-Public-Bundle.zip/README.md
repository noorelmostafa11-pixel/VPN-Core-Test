# VPN-Core-Test public test-only bundle

Contains the original precompiled Windows vpn-core.exe and vpn-tls.dll from vpn-core-expanded 0.4.2, matching Test-Batch.ps1 and Batch-Process.ps1, and the pinned Pre node lists. No core source, third-party vendor source, or build tools are included. The original ZIP is unchanged.

On Windows, unpack and run: `powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\Test-Batch.ps1 -InspectOnly` for a non-network inspection, or omit `-InspectOnly` to test live connections.

A public GitHub repository makes both node configuration URIs and binaries available to everyone. Do not add extra private credentials.
